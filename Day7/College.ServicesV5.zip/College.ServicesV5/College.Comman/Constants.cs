﻿namespace College.Common
{

    public static class Constants
    {
        public static string ConnectionString { get; set; } = "ConnectionStrings:CollegeDBConnectionString";
    }

}
