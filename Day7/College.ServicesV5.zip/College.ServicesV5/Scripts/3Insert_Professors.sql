
INSERT INTO [dbo].[Professors] ( [Name], [Doj], [Teaches], [Salary], [IsPhd])  VALUES ('Shiva Sai', '01-Jan-2010', 'C Sharp; Java; Python', 1234.56, 1 )
GO
INSERT INTO [dbo].[Professors] ( [Name], [Doj], [Teaches], [Salary], [IsPhd])  VALUES ('Mathew Philips', '01-Feb-2010', 'C Sharp; Java; Python', 1234.56, 1 )
GO
INSERT INTO [dbo].[Professors] ( [Name], [Doj], [Teaches], [Salary], [IsPhd])  VALUES ('Mohd Azim', '01-Mar-2010', 'C Sharp; Java; Python', 1234.56, 1 )
GO

