1. Install the SQL scrips from Scrips folder.

